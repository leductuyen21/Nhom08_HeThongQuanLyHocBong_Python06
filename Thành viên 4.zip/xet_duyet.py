from ho_so_hoc_bong import HoSoHocBong


class XetDuyetHocBong:
    """Quản lý việc tạo, xét duyệt và hiển thị kết quả hồ sơ học bổng."""

    def __init__(self):
        self.danh_sach_ho_so = []

    def tao_ho_so(self, ma_ho_so, ma_sinh_vien, ma_hoc_bong):
        """Tạo hồ sơ mới; không cho phép trùng mã hồ sơ."""
        if not ma_ho_so or not ma_sinh_vien or not ma_hoc_bong:
            print("Lỗi: Mã hồ sơ, mã sinh viên và mã học bổng không được để trống.")
            return None

        for ho_so in self.danh_sach_ho_so:
            if ho_so.ma_ho_so == ma_ho_so:
                print(f"Lỗi: Mã hồ sơ {ma_ho_so} đã tồn tại.")
                return None

        ho_so = HoSoHocBong(ma_ho_so, ma_sinh_vien, ma_hoc_bong)
        self.danh_sach_ho_so.append(ho_so)
        print(f"Đã tạo hồ sơ {ma_ho_so} thành công.")
        return ho_so

    def xet_duyet(self, ma_ho_so, ket_qua, ly_do=""):
        """Duyệt nếu ket_qua là True; từ chối nếu False."""
        for ho_so in self.danh_sach_ho_so:
            if ho_so.ma_ho_so == ma_ho_so:
                if ho_so.trang_thai != "Chờ xét duyệt":
                    print(f"Hồ sơ {ma_ho_so} đã được xử lý trước đó.")
                    return ho_so

                if ket_qua:
                    ho_so.duyet()
                else:
                    ho_so.tu_choi(ly_do)

                print(f"Đã cập nhật kết quả hồ sơ {ma_ho_so}: {ho_so.trang_thai}.")
                return ho_so

        print(f"Lỗi: Không tìm thấy hồ sơ {ma_ho_so}.")
        return None

    def hien_thi_ket_qua(self):
        """Hiển thị tất cả hồ sơ và kết quả xét duyệt."""
        if not self.danh_sach_ho_so:
            print("Chưa có hồ sơ nào.")
            return

        for ho_so in self.danh_sach_ho_so:
            ho_so.hien_thi()
