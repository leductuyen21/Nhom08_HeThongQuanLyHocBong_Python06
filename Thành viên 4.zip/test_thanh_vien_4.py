from xet_duyet import XetDuyetHocBong


def main():
    quan_ly = XetDuyetHocBong()

    quan_ly.tao_ho_so("HS01", "SV01", "HB01")
    quan_ly.tao_ho_so("HS02", "SV02", "HB02")

    quan_ly.xet_duyet("HS01", True)
    quan_ly.xet_duyet("HS02", False, "Điểm học tập chưa đạt yêu cầu")

    print("\n===== KẾT QUẢ XÉT DUYỆT =====")
    quan_ly.hien_thi_ket_qua()


if __name__ == "__main__":
    main()
