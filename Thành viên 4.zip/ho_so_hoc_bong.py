class HoSoHocBong:
    """Lưu thông tin và trạng thái xét duyệt của một hồ sơ học bổng."""

    def __init__(self, ma_ho_so, ma_sinh_vien, ma_hoc_bong):
        self.ma_ho_so = ma_ho_so
        self.ma_sinh_vien = ma_sinh_vien
        self.ma_hoc_bong = ma_hoc_bong
        self.trang_thai = "Chờ xét duyệt"
        self.ly_do = ""

    def duyet(self):
        """Đánh dấu hồ sơ đã được duyệt."""
        self.trang_thai = "Đã duyệt"
        self.ly_do = "Hồ sơ được chấp nhận."

    def tu_choi(self, ly_do):
        """Từ chối hồ sơ và lưu lý do."""
        self.trang_thai = "Từ chối"
        self.ly_do = ly_do or "Không đạt yêu cầu."

    def hien_thi(self):
        """Hiển thị thông tin hồ sơ."""
        print(f"Mã hồ sơ: {self.ma_ho_so}")
        print(f"Mã sinh viên: {self.ma_sinh_vien}")
        print(f"Mã học bổng: {self.ma_hoc_bong}")
        print(f"Trạng thái: {self.trang_thai}")
        print(f"Lý do: {self.ly_do}")
        print("-" * 35)
