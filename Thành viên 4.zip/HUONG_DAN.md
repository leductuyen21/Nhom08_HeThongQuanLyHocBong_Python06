# Nhiệm vụ Thành viên 4 — Hồ sơ và xét duyệt học bổng

## File được giao
- `ho_so_hoc_bong.py`: class `HoSoHocBong`
- `xet_duyet.py`: class `XetDuyetHocBong`
- `test_thanh_vien_4.py`: file chạy thử riêng, không bắt buộc đưa vào chương trình chính.

## Chạy thử
Mở Terminal tại thư mục chứa các file và chạy:

```bash
python test_thanh_vien_4.py
```

Nếu máy dùng lệnh `python3`, chạy `python3 test_thanh_vien_4.py`.

## Các phương thức theo giao diện nhóm
- `HoSoHocBong`: `__init__()`, `duyet()`, `tu_choi()`, `hien_thi()`
- `XetDuyetHocBong`: `tao_ho_so()`, `xet_duyet()`, `hien_thi_ket_qua()`

## Commit và push
Chép hai file code được giao vào thư mục dự án nhóm, sau đó chạy:

```bash
git pull --rebase origin main
git add ho_so_hoc_bong.py xet_duyet.py
git commit -m "Hoan thanh chuc nang ho so va xet duyet hoc bong"
git pull --rebase origin main
git push origin main
```

Nếu Git báo xung đột, dừng lại và xử lý xung đột trước; không dùng `git push --force`.

Lưu ý: Đây là phần code theo giao diện class nhóm đã cung cấp. Trước khi ghép vào dự án hoàn chỉnh, cần đối chiếu với cấu trúc dữ liệu và cách gọi hàm trong `main.py` của nhóm.
